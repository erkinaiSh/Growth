<?php
header('Location: news/index.php');
?>