<?php if (false): ?>
	nik ta mere mec
<?php else: ?>
	cc mec
<?php endif ?>
